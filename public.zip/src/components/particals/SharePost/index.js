import React from 'react'

const Index = () => {


  return (
    <>
        <div className="card card-body card-post mb-5"></div>
    </>
  )
}

export default Index
import React from 'react'

function FriendsChat() {
  return (
    <>
        <p>This Is textT</p>
    </>
  )
}

export default FriendsChat

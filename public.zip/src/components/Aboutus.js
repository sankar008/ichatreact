import React from "react";

const Aboutus = () => {
  return (
    <>
     <div>Aboutus</div>
    </>
  );
};

export default Aboutus;